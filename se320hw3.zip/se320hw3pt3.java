import java.text.NumberFormat;
import java.util.*;

public class se320hw3pt3
{
    public static void main(String[] args)
    {
        NumberFormat uk = NumberFormat.getInstance(Locale.UK);//number format for uk standard
        uk.setMaximumFractionDigits(2);//set only 2 decimal places
        System.out.println(uk.format(12345.678));//format that number in uk standard
        
        NumberFormat dollar = NumberFormat.getCurrencyInstance(Locale.US);//declare us standard currency
        System.out.println(dollar.format(12345.678));//print the number in us currency
        
        NumberFormat usNum = NumberFormat.getInstance(Locale.US);//declare numberformat for us
        try
        {
            Number number = usNum.parse("12,345.678");//try to parse the number out of that
            System.out.println(number.doubleValue());//print result
        }
        catch (java.text.ParseException ex) //catch an error on the parse
        {
            System.out.println("Parse failed");      
        }
    }
}