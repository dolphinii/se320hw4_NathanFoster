import java.util.*;
public class SE320HW3P1 
{
	public static void main(String args[])
	{
		//declare variables
		Set<String> set1=new LinkedHashSet<>();
		Set<String> set2=new LinkedHashSet<>();
		
		//declare sets to be operated and manipulated
		Set<String> union=new LinkedHashSet<>();
		Set<String> difference1=new LinkedHashSet<>();
		Set<String> difference2=new LinkedHashSet<>();
		Set<String> intersection=new LinkedHashSet<>();
		
		//add all values to starting sets
		set1.add("George");
		set1.add("Jim");
		set1.add("John");
		set1.add("Blake");
		set1.add("Kevin");
		set1.add("Michael");
		
		set2.add("George");
		set2.add("Katie");
		set2.add("Kevin");
		set2.add("Michelle");
		set2.add("Ryan");
		
		union.addAll(set1);//add all elements from set1 to union
		union.addAll(set2);//add all new elements from set2 to union
		
		difference1.addAll(set1);//add all elements from set1 to difference1
		difference1.removeAll(set2);//remove all repeat elements from set2 to difference1
		
		difference2.addAll(set2);//add all elements from set2 to difference2
		difference2.removeAll(set1);//remove all repeat elements from set1 to difference2
		
		intersection.addAll(set1);//add all elements from set1 to intersection
		intersection.retainAll(set2);//retain everything in intersection thats in set2
		
		//print results
		System.out.println("Union: "+union);
		System.out.println("Difference (2 from 1): "+difference1);
		System.out.println("Difference (1 from 2): "+difference2);
		System.out.println("Intersection: "+intersection);
	}
}
