import java.io.*;
import java.util.*;
public class se320hw3pt2 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		File file = new File("C:\\Users\\Nathan\\eclipse-workspace\\SE320HW3P1\\src\\input.txt");//new file from my directory, change when running
		if (!file.isFile())//if the file is not a file or there is some error
			throw new FileNotFoundException(file + " is not a file.");//print result

		try (BufferedReader readerIn = new BufferedReader(new FileReader(file)))//try to read input from the file
		{
			String input=readerIn.readLine();//read the line of text from input.txt, important note it is only one line of text space seperated
			String[] temp=input.split("\\s+");//make an array of strings from the input, seperating every value with spaces as new elements
			TreeSet<String> words=new TreeSet<>();//declaring treeset
			for(int i=0;i<temp.length;i++)//loop through temp array and insert values into the tree set
			{
				words.add(temp[i]);
			}
			System.out.println(words);
		} 
		catch (IOException e) //catch any exception that occurs
		{
			e.printStackTrace();
			System.exit(0);//close program
		}
	}
}
